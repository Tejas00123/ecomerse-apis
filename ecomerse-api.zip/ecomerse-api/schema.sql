-- Drop tables if they already exist (to avoid conflicts)
DROP TABLE IF EXISTS OrderItem;
DROP TABLE IF EXISTS Orders;
DROP TABLE IF EXISTS Cart;
DROP TABLE IF EXISTS Product;
DROP TABLE IF EXISTS Category;
DROP TABLE IF EXISTS Users;

-- Create Users Table
CREATE TABLE Users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('customer', 'admin') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create Categories Table
CREATE TABLE Category (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL
);

-- Create Products Table
-- CREATE TABLE Product (
--     id INT AUTO_INCREMENT PRIMARY KEY,
--     name VARCHAR(255) NOT NULL,
--     description TEXT,
--     price DECIMAL(10,2) NOT NULL,
--     stock INT NOT NULL,
--     category_id INT,
--     FOREIGN KEY (category_id) REFERENCES Category(id) ON DELETE SET NULL
-- );

-- CREATE TABLE Product (
--     id INT AUTO_INCREMENT PRIMARY KEY,
--     name VARCHAR(255) NOT NULL,
--     description VARCHAR(255),
--     price DECIMAL(10,2) NOT NULL,
--     discount DECIMAL(5,2) DEFAULT 0, -- Discount percentage
--     final_price DECIMAL(10,2) GENERATED ALWAYS AS (price - (price * (discount / 100))) STORED, -- Auto-calculated price
--     stock INT NOT NULL DEFAULT 0,
--     expiryDate DATE DEFAULT NULL, -- Expiry date for perishable products
--     category_id INT,
--     product_url VARCHAR(255) UNIQUE NOT NULL, -- Unique URL for SEO-friendly links
--     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
--     updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
--     FOREIGN KEY (category_id) REFERENCES Category(id) ON DELETE SET NULL
-- );

-- CREATE TABLE Product (
--     id INT AUTO_INCREMENT PRIMARY KEY,
--     name VARCHAR(255) NOT NULL,
--     slug VARCHAR(255) UNIQUE NOT NULL, -- Unique slug for SEO-friendly URLs
--     description VARCHAR(255),
--     price DECIMAL(10,2) NOT NULL,
--     discount DECIMAL(5,2) DEFAULT 0, -- Discount percentage
--     final_price DECIMAL(10,2) GENERATED ALWAYS AS (price - (price * (discount / 100))) STORED, -- Auto-calculated price
--     stock INT NOT NULL DEFAULT 0,
--     expiryDate DATE DEFAULT NULL, -- Expiry date for perishable products
--     category_id INT,
--     product_url VARCHAR(255) UNIQUE NOT NULL, -- Unique URL for product
--     image VARCHAR(255) DEFAULT NULL, -- Image filename/path
--     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
--     updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
--     FOREIGN KEY (category_id) REFERENCES Category(id) ON DELETE SET NULL
-- );

CREATE TABLE Product (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL, -- Unique slug for SEO-friendly URLs
    description VARCHAR(255),
    price DECIMAL(10,2) NOT NULL,
    discount DECIMAL(5,2) DEFAULT 0, -- Discount percentage
    final_price DECIMAL(10,2) GENERATED ALWAYS AS (price - (price * (discount / 100))) STORED, -- Auto-calculated price
    stock INT NOT NULL DEFAULT 0,
    expiryDate DATE DEFAULT NULL, -- Expiry date for perishable products
    category_id INT,
    product_url VARCHAR(255) UNIQUE NOT NULL, -- Unique URL for product
    image VARCHAR(255) DEFAULT NULL, -- Image filename/path
    role ENUM('admin', 'user') NOT NULL DEFAULT 'user', -- Role-based access (admin/user)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES Category(id) ON DELETE SET NULL
);


-- Create Orders Table
CREATE TABLE Orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
);

-- Create Order Items Table
CREATE TABLE OrderItem (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES Orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES Product(id) ON DELETE CASCADE
);

-- Create Cart Table
CREATE TABLE Cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES Product(id) ON DELETE CASCADE
);
