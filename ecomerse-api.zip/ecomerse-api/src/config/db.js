require("dotenv").config(); // Load environment variables

const { Sequelize } = require("sequelize");

const sequelize = new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASSWORD, {
  host: process.env.DB_HOST,
  dialect: "mysql", // ✅ Explicitly specify MySQL dialect
  port: process.env.DB_PORT || 3306,
  logging: false, // Optional: Disable logging SQL queries in the console
});

module.exports = sequelize;
