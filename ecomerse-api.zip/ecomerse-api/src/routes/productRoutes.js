const express = require('express');
const router = express.Router();
const { getProducts, getProductById, createProduct, updateProduct, deleteProduct, uploadProductImage} = require('../controllers/productController');
const { authenticateUser, authorizeRole } = require("../middleware/authMiddleware");


// 🛍️ Get all products (Accessible to everyone
router.get('/report', getProducts);
router.get('/:id', getProductById);

// 🔐 Admin-only routes
router.post("/add",uploadProductImage, authenticateUser, authorizeRole(["admin"]), createProduct);
router.put("/update/:id",uploadProductImage, authenticateUser, authorizeRole(["admin"]), updateProduct);
router.delete("/delete/:id", authenticateUser, authorizeRole(["admin"]), deleteProduct);


/* // ➕ Create a product (with image upload)
router.post("/add",  uploadProductImage, createProduct);


// ✏️ Update a product
router.put('/update/:id',  uploadProductImage, updateProduct);
 
// ❌ Delete a product
router.delete('/delete/:id', deleteProduct);
*/

module.exports = router;
