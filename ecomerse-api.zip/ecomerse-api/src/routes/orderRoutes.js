const express = require("express");
const router = express.Router();
const { getOrders, getOrderById, createOrder, updateOrderStatus, deleteOrder } = require("../controllers/orderController");

// 📜 Get all orders
router.get("/report", getOrders);

// 🔍 Get a single order by ID
router.get("/:id", getOrderById);

// ➕ Create a new order
router.post("/add", createOrder);

// ✏️ Update order status
router.put("/update/:id", updateOrderStatus);

// ❌ Delete an order
router.delete("/delete/:id", deleteOrder);

module.exports = router;
