const Order = require("../models/Order");

// Get all orders
exports.getOrders = async (req, res) => {
    try {
        const orders = await Order.findAll();
        res.json(orders);
    } catch (error) {
        res.status(500).json({ error: "Error fetching orders" });
    }
};

// Get order by ID
exports.getOrderById = async (req, res) => {
    try {
        const { id } = req.params;
        const order = await Order.findByPk(id);
        if (!order) return res.status(404).json({ error: "Order not found" });

        res.json(order);
    } catch (error) {
        res.status(500).json({ error: "Error fetching order" });
    }
};

// Create a new order
exports.createOrder = async (req, res) => {
    try {
        const { userId, totalAmount, status } = req.body;
        const order = await Order.create({ userId, totalAmount, status });

        res.status(201).json(order);
    } catch (error) {
        res.status(500).json({ error: "Error creating order" });
    }
};

// Update order status
exports.updateOrderStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        const order = await Order.findByPk(id);
        if (!order) return res.status(404).json({ error: "Order not found" });

        await order.update({ status });
        res.json({ message: "Order status updated successfully" });
    } catch (error) {
        res.status(500).json({ error: "Error updating order" });
    }
};

// Delete an order
exports.deleteOrder = async (req, res) => {
    try {
        const { id } = req.params;
        const order = await Order.findByPk(id);
        if (!order) return res.status(404).json({ error: "Order not found" });

        await order.destroy();
        res.json({ message: "Order deleted successfully" });
    } catch (error) {
        res.status(500).json({ error: "Error deleting order" });
    }
};
