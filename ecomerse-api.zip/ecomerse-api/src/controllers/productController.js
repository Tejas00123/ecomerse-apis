const multer = require("multer");
const path = require("path");
const Product = require("../models/Product");
const slugify = require("slugify");
const { Op } = require("sequelize");

// Configure Multer for image uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

// File filter: Only allow image files
const fileFilter = (req, file, cb) => {
  if (file.mimetype.startsWith("image/")) {
    cb(null, true);
  } else {
    cb(new Error("Only image files are allowed!"), false);
  }
};

// Initialize Multer
const upload = multer({ storage, fileFilter });
exports.uploadProductImage = upload.single("image");

// Generate a unique slug for the product
const generateUniqueSlug = async (name, id = null) => {
  let baseSlug = slugify(name, { lower: true, strict: true });
  let slug = baseSlug;
  let counter = 1;

  while (await Product.findOne({ where: { slug, id: { [Op.ne]: id } } })) {
    slug = `${baseSlug}-${counter}`;
    counter++;
  }

  return slug;
};

// 🛍️ Get all products with search, pagination, and discounts
exports.getProducts = async (req, res) => {
  try {
    const today = new Date();
    const { page = 1, limit = 10, search = "", sortBy = "createdAt", order = "DESC" } = req.query;
    const offset = (page - 1) * limit;

    const whereClause = {
      [Op.and]: [
        {
          [Op.or]: [
            { expiryDate: { [Op.is]: null } },
            { expiryDate: { [Op.gt]: today } }
          ]
        },
        search
          ? {
              [Op.or]: [
                { name: { [Op.like]: `%${search}%` } },
                { description: { [Op.like]: `%${search}%` } }
              ]
            }
          : {},
      ],
    };

    const { rows: products, count } = await Product.findAndCountAll({
      where: whereClause,
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [[sortBy, order.toUpperCase()]],
    });

    const updatedProducts = products.map(product => ({
      ...product.toJSON(),
      finalPrice: (product.price - (product.price * (product.discount / 100))).toFixed(2),
    }));

    res.json({
      totalProducts: count,
      totalPages: Math.ceil(count / limit),
      currentPage: parseInt(page),
      products: updatedProducts,
    });
  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

// 🛍️ Get a single product by ID
exports.getProductById = async (req, res) => {
  try {
    const { id } = req.params;
    const product = await Product.findByPk(id);

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    res.json(product);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error });
  }
};

// ➕ Create a product with image upload
exports.createProduct = async (req, res) => {
  try {
    const { name, description, price, discount, stock, expiryDate } = req.body;

    if (!name || !price || !stock) {
      return res.status(400).json({ message: "Name, price, and stock are required" });
    }

    const slug = await generateUniqueSlug(name);
    const productUrl = `http://yourdomain.com/products/${slug}`;
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;

    const product = await Product.create({
      name,
      slug,
      description,
      price,
      discount,
      stock,
      expiryDate,
      productUrl, // ✅ Ensure productUrl is stored
      imageUrl,
    });

    res.status(201).json({ message: "Product created successfully", product });
  } catch (error) {
    console.error("Error creating product:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

// ✏️ Update a product with image
exports.updateProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, price, discount, stock, expiryDate } = req.body;

    const product = await Product.findByPk(id);
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    const slug = await generateUniqueSlug(name, id);
    const productUrl = `http://yourdomain.com/products/${slug}`;
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : product.imageUrl;

    await product.update({
      name,
      slug,
      description,
      price,
      discount,
      stock,
      expiryDate,
      productUrl, // ✅ Ensure updated productUrl
      imageUrl,
    });

    res.json({ message: "Product updated successfully", product });
  } catch (error) {
    console.error("Error updating product:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

// ❌ Delete a product
exports.deleteProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const product = await Product.findByPk(id);
    if (!product) return res.status(404).json({ message: 'Product not found' });

    await product.destroy();
    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error });
  }
};
