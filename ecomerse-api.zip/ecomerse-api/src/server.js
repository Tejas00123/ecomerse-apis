require("dotenv").config();
const express = require("express");
const cors = require("cors");
const { connectDB } = require("./config/db");
const { sequelize } = require("./models"); // Import models
const authRoutes = require("./routes/authRoutes");//Import authRoutes
const productRoutes = require("./routes/productRoutes"); // Import Product Routes
const orderRoutes = require("./routes/orderRoutes"); // Import Order Routes
const errorHandler = require("./middleware/errorHandler"); // Import error handler
const authMiddleware = require("./middleware/authMiddleware")
const app = express();

// Middleware
app.use(cors());
app.use(express.json()); // To parse JSON requests
app.use("/api/auth", authRoutes);
// Use Product Routes
app.use("/api/products", productRoutes);
// Use Order Routes
app.use("/api/orders", orderRoutes);

// Use the error handling middleware
app.use(errorHandler); 

// Default route
app.get("/", (req, res) => {
  res.send("E-commerce API is running...");
});

// Sync Database
sequelize.sync({ force: false }) // Change to "true" only if you want to drop tables and recreate
  .then(() => console.log("✅ Database synced"))
  .catch((err) => console.error("❌ Error syncing database:", err));

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});


/* // Sync Database
sequelize.sync()
  .then(() => console.log("Database synced"))
  .catch(err => console.log("Error syncing database:", err));
 */