const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");

const Product = sequelize.define("Product", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  slug: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true, // Ensure uniqueness
  },
  description: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  price: {
    type: DataTypes.FLOAT,
    allowNull: false,
  },
  discount: {
    type: DataTypes.FLOAT,
    defaultValue: 0, // Discount percentage (e.g., 10 for 10%)
    validate: {
      min: 0,
      max: 100, // Ensures discount is within a valid range
    },
  },
  finalPrice: {
    type: DataTypes.VIRTUAL, // Not stored in DB, calculated dynamically
    get() {
      return this.price - (this.price * (this.discount / 100));
    },
  },
  stock: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
  },
  expiryDate: {
    type: DataTypes.DATE,
    allowNull: true, // Optional expiry date
  },
  productUrl: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true, // Unique URL for SEO-friendly links
  },
  imageUrl: {
    type: DataTypes.STRING, // Store the image URL/path
    allowNull: true,
  },
  categoryId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: "Categories", // Matches SQL table "Category"
      key: "id",
    },
    onDelete: "SET NULL",
  },
  createdAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  updatedAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
    onUpdate: DataTypes.NOW,
  },
});

module.exports = Product;
